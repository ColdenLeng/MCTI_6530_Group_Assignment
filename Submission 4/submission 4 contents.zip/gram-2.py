import pandas as pd
from collections import Counter

# ===================== 2-GRAM PROCESSING =====================

def generate_2grams(sequence):
    """Generate 2-grams from a sequence of opcodes."""
    return ['{' + ', '.join(sequence[i:i + 2]) + '}' for i in range(len(sequence) - 1)]

# Step 1: Collect unique 2-grams across the 'Opcodes' column
unique_2grams = set()
for opcodes in df['Opcodes'].fillna(''):  # Handle missing values
    opcode_list = [op.strip() for op in opcodes.split(',')]
    two_grams = generate_2grams(opcode_list)
    unique_2grams.update(two_grams)

# Convert unique 2-grams to a sorted list for consistent column ordering
unique_2grams = sorted(unique_2grams)

# Step 2: Initialize a DataFrame to store 2-gram counts
two_gram_counts_df = pd.DataFrame(0, index=range(len(df)), columns=unique_2grams)

# Step 3: Process each row to count 2-grams
for i, opcodes in enumerate(df['Opcodes'].fillna('')):
    opcode_list = [op.strip() for op in opcodes.split(',')]  # Split by comma and strip spaces
    two_grams = generate_2grams(opcode_list)
    counts_2gram = Counter(two_grams)  # Count each unique 2-gram
    for two_gram, count in counts_2gram.items():
        if two_gram in two_gram_counts_df.columns:
            two_gram_counts_df.at[i, two_gram] = count

# Step 4: Extract the feature matrix for 2-grams
x_2gram = two_gram_counts_df.values

# Display results
print("2-Gram Feature Matrix (first few rows):")
print(two_gram_counts_df.head())
print("\nShape of x_2gram:", x_2gram.shape)