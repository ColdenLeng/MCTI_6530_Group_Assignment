import pandas as pd
from collections import Counter

# ===================== 1-GRAM PROCESSING =====================

# Step 1: Collect all unique 1-grams across the entire 'Opcodes' column
unique_1grams = set(op.strip() for opcodes in df['Opcodes'].fillna('') for op in opcodes.split(','))

# Convert unique 1-grams to a sorted list to ensure consistent column ordering
unique_1grams = sorted(unique_1grams)

# Step 2: Initialize a DataFrame to store counts with rows for each sample and columns for each unique opcode
one_gram_counts_df = pd.DataFrame(0, index=range(len(df)), columns=unique_1grams)

# Step 3: Process each row in the DataFrame
for i, opcodes in enumerate(df['Opcodes'].fillna('')):  # Fill missing values with an empty string
    opcode_list = [op.strip() for op in opcodes.split(',')]  # Split by comma and strip spaces
    counts_1gram = Counter(opcode_list)  # Count occurrences of each opcode
    for opcode, count in counts_1gram.items():
        if opcode in one_gram_counts_df.columns:  # Ensure opcode is in columns
            one_gram_counts_df.at[i, opcode] = count

# Step 4: Extract the feature matrix and target values
x_1gram = one_gram_counts_df.values
y_1gram = df['APT'].values  # Ensure 'APT' column exists for target values

# Display results
print("1-Gram Feature Matrix (first few rows):")
print(one_gram_counts_df.head())
print("\nShape of x_1gram:", x_1gram.shape)