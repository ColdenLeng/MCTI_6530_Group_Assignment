import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Set the style for seaborn plots
sns.set(style="whitegrid")


# Preprocessing function - reads and cleans data
def preprocess_opcodes(file_path):
    """
    Load the dataset from the CSV file, and extract opcodes and labels.

    Args:
        file_path (str): Path to the CSV file containing the data.

    Returns:
        data (list): A list of opcode sequences (each entry is a string of opcodes).
        labels (list): A list of labels (APT groups) corresponding to each opcode sequence.
    """
    # Load the CSV file into a DataFrame
    df = pd.read_csv(file_path)
    # Extract the opcodes and labels as lists
    data = df['Opcodes'].tolist()
    labels = df['APT'].tolist()
    return data, labels


# Load and preprocess data from CSV file
data, labels = preprocess_opcodes('/Users/haihai/PycharmProjects/assignment2/opcodes.csv')

# Split dataset into 80% training and 20% testing
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)


# Feature extraction function - ensures that the same CountVectorizer is used for both training and testing
def extract_features(train_data, test_data, ngram=1):
    """
    Convert opcode sequences to feature vectors using n-grams.

    Args:
        train_data (list): List of training opcode sequences.
        test_data (list): List of testing opcode sequences.
        ngram (int): The size of n-grams to be used (1 for 1-gram, 2 for 2-gram, etc.).

    Returns:
        X_train (sparse matrix): Transformed training data into feature vectors.
        X_test (sparse matrix): Transformed testing data into feature vectors.
    """
    # Define CountVectorizer with specified n-gram range
    vectorizer = CountVectorizer(ngram_range=(ngram, ngram))
    # Fit the vectorizer on the training data and transform it to obtain feature vectors
    X_train = vectorizer.fit_transform(train_data)
    # Transform the test data to feature vectors using the same vocabulary
    X_test = vectorizer.transform(test_data)
    return X_train, X_test


# Extract 1-Gram features
X_train_1gram, X_test_1gram = extract_features(X_train, X_test, ngram=1)

# Extract 2-Gram features
X_train_2gram, X_test_2gram = extract_features(X_train, X_test, ngram=2)

# Standardize (normalize) the extracted features
scaler_1gram = StandardScaler(with_mean=False)  # Initialize scaler without mean adjustment for sparse data
X_train_1gram = scaler_1gram.fit_transform(X_train_1gram)
X_test_1gram = scaler_1gram.transform(X_test_1gram)

scaler_2gram = StandardScaler(with_mean=False)
X_train_2gram = scaler_2gram.fit_transform(X_train_2gram)
X_test_2gram = scaler_2gram.transform(X_test_2gram)


# Define a function to evaluate models and display metrics and confusion matrix
def evaluate_model(model, X_train, X_test, y_train, y_test, model_name):
    """
    Train a model, evaluate its performance on test data, and display metrics and confusion matrix.

    Args:
        model: Machine learning model to be trained and evaluated.
        X_train: Training data features.
        X_test: Testing data features.
        y_train: Training data labels.
        y_test: Testing data labels.
        model_name (str): Name of the model for labeling purposes.

    Returns:
        accuracy, recall, precision, f1 (float): The calculated performance metrics.
    """
    model.fit(X_train, y_train)  # Train the model
    y_pred = model.predict(X_test)  # Predict on test data

    # Calculate performance metrics
    accuracy = accuracy_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    cm = confusion_matrix(y_test, y_pred)  # Get confusion matrix without normalization

    # Print metrics for each model
    print(f"{model_name} - Accuracy: {accuracy}")
    print(f"{model_name} - Recall: {recall}")
    print(f"{model_name} - Precision: {precision}")
    print(f"{model_name} - F1 Score: {f1}")

    # Plot confusion matrix for visual insight into predictions
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='coolwarm', cbar=False)
    plt.title(f'{model_name} Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()

    return accuracy, recall, precision, f1


# Initialize the machine learning models to be evaluated
svm_model = SVC()
knn_model = KNeighborsClassifier(n_neighbors=3)
dt_model = DecisionTreeClassifier()

# Dictionary to store results for visualization
results = {'Model': [], 'Accuracy': [], 'Recall': [], 'Precision': [], 'F1 Score': []}

# Evaluate models on 1-Gram features
print("1-Gram Features:")
for model, name in zip([svm_model, knn_model, dt_model], ["SVM (1-Gram)", "KNN (1-Gram)", "Decision Tree (1-Gram)"]):
    acc, rec, prec, f1 = evaluate_model(model, X_train_1gram, X_test_1gram, y_train, y_test, name)
    results['Model'].append(name)
    results['Accuracy'].append(acc)
    results['Recall'].append(rec)
    results['Precision'].append(prec)
    results['F1 Score'].append(f1)

# Evaluate models on 2-Gram features
print("2-Gram Features:")
for model, name in zip([svm_model, knn_model, dt_model], ["SVM (2-Gram)", "KNN (2-Gram)", "Decision Tree (2-Gram)"]):
    acc, rec, prec, f1 = evaluate_model(model, X_train_2gram, X_test_2gram, y_train, y_test, name)
    results['Model'].append(name)
    results['Accuracy'].append(acc)
    results['Recall'].append(rec)
    results['Precision'].append(prec)
    results['F1 Score'].append(f1)

# Convert results into a DataFrame for easy visualization
results_df = pd.DataFrame(results)

# Plot the performance metrics for each model
plt.figure(figsize=(14, 10))
metrics = ['Accuracy', 'Recall', 'Precision', 'F1 Score']
for i, metric in enumerate(metrics, 1):
    plt.subplot(2, 2, i)  # Create subplot for each metric
    sns.barplot(x='Model', y=metric, data=results_df, hue='Model', dodge=False, palette="viridis")
    plt.title(metric)
    plt.xticks(rotation=45)
    plt.ylim(0, 1)  # Set y-axis limits to 0-1 for consistency across metrics
    plt.legend([], [], frameon=False)  # Hide legend for simplicity

# Set a main title for the entire figure
plt.suptitle("Model Performance Metrics for 1-Gram and 2-Gram Features", fontsize=16)
plt.tight_layout(rect=[0, 0, 1, 0.96])  # Adjust layout to fit the title
plt.show()
